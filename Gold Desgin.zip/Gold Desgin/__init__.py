import bpy
import os

bl_info = {
    "name": "Gold Desgin",
    "description": "New Template Gold Desgin be woow3d",
    "author": "Abdulrahman Baggash",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "category": "Templates",
}

# الحصول على مسار ملف الإضافة
addon_dir = os.path.dirname(__file__)
preset_path = os.path.join(addon_dir, "setting.blend")

# دالة تضيف خيار فتح الملف المخصص عند بدء مشروع جديد
def my_template_operator(self, context):
    layout = self.layout
    op = layout.operator("wm.open_mainfile", text="Gold Desgin")
    op.filepath = preset_path

# تسجيل الخيار الجديد في قائمة "ملف > جديد"
def register():
    bpy.types.TOPBAR_MT_file_new.append(my_template_operator)

def unregister():
    bpy.types.TOPBAR_MT_file_new.remove(my_template_operator)

if __name__ == "__main__":
    register()
